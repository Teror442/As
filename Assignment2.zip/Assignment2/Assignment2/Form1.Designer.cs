﻿namespace Assignment2
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtType = new TextBox();
            txtPrice = new TextBox();
            txtBrand = new TextBox();
            txtColor = new TextBox();
            txtSize = new TextBox();
            txtFabric = new TextBox();
            txtCut = new TextBox();
            btnAddProduct = new Button();
            btnClear = new Button();
            lblResult = new Label();
            lstProducts = new ListBox();
            btnSave = new Button();
            btnLoad = new Button();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            txtFilterColor = new TextBox();
            txtFilterType = new TextBox();
            txtFilterSize = new TextBox();
            label8 = new Label();
            label9 = new Label();
            label10 = new Label();
            btnFilter = new Button();
            SuspendLayout();
            // 
            // txtType
            // 
            txtType.Location = new Point(150, 50);
            txtType.Name = "txtType";
            txtType.Size = new Size(218, 23);
            txtType.TabIndex = 0;
            // 
            // txtPrice
            // 
            txtPrice.Location = new Point(150, 430);
            txtPrice.Name = "txtPrice";
            txtPrice.Size = new Size(218, 23);
            txtPrice.TabIndex = 1;
            // 
            // txtBrand
            // 
            txtBrand.Location = new Point(150, 362);
            txtBrand.Name = "txtBrand";
            txtBrand.Size = new Size(218, 23);
            txtBrand.TabIndex = 2;
            // 
            // txtColor
            // 
            txtColor.Location = new Point(150, 180);
            txtColor.Name = "txtColor";
            txtColor.Size = new Size(218, 23);
            txtColor.TabIndex = 3;
            // 
            // txtSize
            // 
            txtSize.Location = new Point(150, 302);
            txtSize.Name = "txtSize";
            txtSize.Size = new Size(218, 23);
            txtSize.TabIndex = 4;
            // 
            // txtFabric
            // 
            txtFabric.Location = new Point(150, 239);
            txtFabric.Name = "txtFabric";
            txtFabric.Size = new Size(218, 23);
            txtFabric.TabIndex = 5;
            // 
            // txtCut
            // 
            txtCut.Location = new Point(150, 118);
            txtCut.Name = "txtCut";
            txtCut.Size = new Size(218, 23);
            txtCut.TabIndex = 6;
            // 
            // btnAddProduct
            // 
            btnAddProduct.Location = new Point(561, 58);
            btnAddProduct.Name = "btnAddProduct";
            btnAddProduct.Size = new Size(168, 38);
            btnAddProduct.TabIndex = 7;
            btnAddProduct.Text = "Add Product";
            btnAddProduct.UseVisualStyleBackColor = true;
            // 
            // btnClear
            // 
            btnClear.Location = new Point(561, 118);
            btnClear.Name = "btnClear";
            btnClear.Size = new Size(168, 36);
            btnClear.TabIndex = 8;
            btnClear.Text = "Clear Form";
            btnClear.UseVisualStyleBackColor = true;
            // 
            // lblResult
            // 
            lblResult.AutoSize = true;
            lblResult.Location = new Point(511, 362);
            lblResult.Name = "lblResult";
            lblResult.Size = new Size(61, 15);
            lblResult.TabIndex = 9;
            lblResult.Text = "Final Price";
            // 
            // lstProducts
            // 
            lstProducts.FormattingEnabled = true;
            lstProducts.ItemHeight = 15;
            lstProducts.Location = new Point(511, 400);
            lstProducts.Name = "lstProducts";
            lstProducts.Size = new Size(577, 124);
            lstProducts.TabIndex = 10;
            // 
            // btnSave
            // 
            btnSave.Location = new Point(561, 169);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(168, 43);
            btnSave.TabIndex = 11;
            btnSave.Text = "Save";
            btnSave.UseVisualStyleBackColor = true;
            // 
            // btnLoad
            // 
            btnLoad.Location = new Point(561, 239);
            btnLoad.Name = "btnLoad";
            btnLoad.Size = new Size(168, 36);
            btnLoad.TabIndex = 12;
            btnLoad.Text = "Load";
            btnLoad.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(34, 58);
            label1.Name = "label1";
            label1.Size = new Size(34, 15);
            label1.TabIndex = 13;
            label1.Text = "Type:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(34, 188);
            label2.Name = "label2";
            label2.Size = new Size(39, 15);
            label2.TabIndex = 14;
            label2.Text = "Color:";
      
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(34, 126);
            label3.Name = "label3";
            label3.Size = new Size(29, 15);
            label3.TabIndex = 15;
            label3.Text = "Cut:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(34, 247);
            label4.Name = "label4";
            label4.Size = new Size(42, 15);
            label4.TabIndex = 16;
            label4.Text = "Fabric:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(34, 310);
            label5.Name = "label5";
            label5.Size = new Size(30, 15);
            label5.TabIndex = 17;
            label5.Text = "Size:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(32, 433);
            label6.Name = "label6";
            label6.Size = new Size(36, 15);
            label6.TabIndex = 18;
            label6.Text = "Price:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(34, 370);
            label7.Name = "label7";
            label7.Size = new Size(41, 15);
            label7.TabIndex = 19;
            label7.Text = "Brand:";
            // 
            // txtFilterColor
            // 
            txtFilterColor.Location = new Point(948, 50);
            txtFilterColor.Name = "txtFilterColor";
            txtFilterColor.Size = new Size(100, 23);
            txtFilterColor.TabIndex = 20;
            // 
            // txtFilterType
            // 
            txtFilterType.Location = new Point(948, 142);
            txtFilterType.Name = "txtFilterType";
            txtFilterType.Size = new Size(100, 23);
            txtFilterType.TabIndex = 21;
            // 
            // txtFilterSize
            // 
            txtFilterSize.Location = new Point(948, 92);
            txtFilterSize.Name = "txtFilterSize";
            txtFilterSize.Size = new Size(100, 23);
            txtFilterSize.TabIndex = 22;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(850, 145);
            label8.Name = "label8";
            label8.Size = new Size(34, 15);
            label8.TabIndex = 23;
            label8.Text = "Type:";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(850, 100);
            label9.Name = "label9";
            label9.Size = new Size(30, 15);
            label9.TabIndex = 24;
            label9.Text = "Size:";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(850, 58);
            label10.Name = "label10";
            label10.Size = new Size(39, 15);
            label10.TabIndex = 25;
            label10.Text = "Color:";
            // 
            // btnFilter
            // 
            btnFilter.Location = new Point(1108, 78);
            btnFilter.Name = "btnFilter";
            btnFilter.Size = new Size(126, 37);
            btnFilter.TabIndex = 26;
            btnFilter.Text = "Filter";
            btnFilter.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1273, 678);
            Controls.Add(btnFilter);
            Controls.Add(label10);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(txtFilterSize);
            Controls.Add(txtFilterType);
            Controls.Add(txtFilterColor);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(btnLoad);
            Controls.Add(btnSave);
            Controls.Add(lstProducts);
            Controls.Add(lblResult);
            Controls.Add(btnClear);
            Controls.Add(btnAddProduct);
            Controls.Add(txtCut);
            Controls.Add(txtFabric);
            Controls.Add(txtSize);
            Controls.Add(txtColor);
            Controls.Add(txtBrand);
            Controls.Add(txtPrice);
            Controls.Add(txtType);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtType;
        private TextBox txtPrice;
        private TextBox txtBrand;
        private TextBox txtColor;
        private TextBox txtSize;
        private TextBox txtFabric;
        private TextBox txtCut;
        private Button btnAddProduct;
        private Button btnClear;
        private Label lblResult;
        private ListBox lstProducts;
        private Button btnSave;
        private Button btnLoad;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private TextBox txtFilterColor;
        private TextBox txtFilterType;
        private TextBox txtFilterSize;
        private Label label8;
        private Label label9;
        private Label label10;
        private Button btnFilter;
    }
}
